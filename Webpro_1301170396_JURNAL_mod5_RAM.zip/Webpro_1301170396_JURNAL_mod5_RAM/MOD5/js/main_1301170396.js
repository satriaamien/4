/* 
    Make sure that each id or class is accompanied by your student id
    for example #id_1301171234 , .class_1301171234

    FOR QUESTION No. 2, PLEASE USE $.getJSON function to load the data
    FOR QUESTION No. 3, PLEASE USE $.ajax function to load data
*/

/*-------------------------------------
    PUT YOUR getJSON function here
---------------------------------------*/

$.getJSON("js/data_1301170396.json", function(data){
     $("title").text(data.title);
     $(".contacts_name").text(data.bio.name);
     $(".contacts_birth").text(data.bio.job);
     $(".contacts_address").text(data.bio.birth);
     $(".contacts_phone").text(data.bio.phone);
     $(".contacts_email").text(data.bio.mail);
     $(".avatar_1301170396").attr("src",data.prof_pict);
     $(".alignleft").attr("src",data.prof_pict);
     $(".nama_1301150034").text(data.bio.name);
});


/*-------------------------------------
    End of getJSON Function
---------------------------------------*/




$(document).ready(function(){

/*-------------------------------------
    PUT YOUR $.ajax function here
---------------------------------------*/
    

/*-------------------------------------
    End Of $.ajax function
---------------------------------------*/
})